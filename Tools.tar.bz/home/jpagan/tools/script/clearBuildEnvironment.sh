#!/bin/bash

### NOTES:
## sed '/^#/d' --> remove all comment lines, beginning with #
## sed '/^ /d' --> remove all lines beginning with spaces
## sed -e 's/=.*//' --> removes aeveryrthing after the = sign
## sed -e 's/ / \-n /g' --> insrt -n in the space

# Find all the exports
grep  -i export ~/scripts/setBuildEnvironment.sh | sed '/^#/d' | sed -e '/^ /d' | sed -e 's/=.*//' | sed -e 's/ / \-n /g' >> tmp

# Find all the aliases
grep  -i alias ~/scripts/setBuildEnvironment.sh | sed '/^#/d' | sed -e '/^ /d' | sed -e 's/=.*//' | sed -e 's/alias/unalias/g' >> tmp

# Find all the functions
grep  -i function ~/scripts/setBuildEnvironment.sh | sed -e 's/(.*//'  |   sed -e 's/function/unset \-f/g' >> tmp

. tmp
rm tmp
