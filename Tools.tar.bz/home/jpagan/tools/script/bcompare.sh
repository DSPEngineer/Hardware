#!/bin/bash

APP_PATH=$HOME/bin/bcompare

LD_LIBRARY_PATH=$APP_PATH:$LD_LIBRARY_PATH

PATH=$APP_PATH:$PATH

#echo $PATH
#echo $LD_LIBRARY_PATH
#echo $APP_PATH


$APP_PATH/BCompare $* &
