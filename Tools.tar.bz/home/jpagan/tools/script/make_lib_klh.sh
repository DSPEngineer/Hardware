#!/bin/bash

CONFIGFILE=~/.dxmautobuild
CONFIGLOCAL=.buildid

# Get our config file variables for connection to KLH.
if [ -f "${CONFIGLOCAL}" ] ; then
    source "${CONFIGLOCAL}"
fi
source "${CONFIGFILE}"

# Find KLH and source info
KLHIP=`grep ^devdefine.*ipaddr "${KLHDIR}/klh10.ini" | head -n 1 | sed 's/.*ipaddr=\([^ ]*\).*/\1/'`

CURR_TTY=`tty` # Find out what tty we have been invoked from.

# Create a multiline string variable for use in the expect script.
read -r -d '' EXPECT_GENERAL <<- EXPECT_EOM
    timeout { send "kk\r"; exit 1 }
    eof { send "kk\r"; exit 2 }
    -re "Unrecognized command" { send "kk\r"; exit 3 }
EXPECT_EOM

# Write expect script to a file.
cat > expect_cmds.txt <<EXPECT_EOF
#!/usr/bin/expect
set timeout 10
spawn telnet ${KLHIP}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "login/fast ${KLHUSER} ${KLHPASS}\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "set terminal no pause end\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "set terminal width 132\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "enable\r" }
}
set timeout 60
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "xfetch $2/$1/$1.ctl\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "delete $1.log.*\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "expunge\r" }
}
set timeout 900
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "submit $1.ctl/time:00:15:00\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { sleep 5; send "tail -f $1.log\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "finished executing" { send "\003\003" }
}
set timeout 60
expect {
    ${EXPECT_GENERAL}
    -re "@|!" { send "xstore $1.log '$2'\r" }
}
expect {
    ${EXPECT_GENERAL}
    -re "no such file" { send "kk\r"; exit 4 }
    -re "@|!" { send "kk\r" }
}
set timeout 5
expect {
    ${EXPECT_GENERAL}
    -re "Connection closed" { exit 0 }
}
EXPECT_EOF

# Run expect script from the file created above.
expect -f expect_cmds.txt

# Check the exit code and print out the response.
BATCH_RET=$?
case $BATCH_RET in
    0) printf "\n\nLibrary $1.a was successfully created\n\n";;
    *) printf "\n\nLibrary target:$1.a FAILED!\n\n";;
esac

# Remove the expect file.
#rm -f expect_cmds.txt

# Send exit code up to the caller.
exit $BATCH_RET
