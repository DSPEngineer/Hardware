#!/bin/bash

TOPS20_BUILD_HOST=`grep -iv "\;" KLHHOST/klh10.ini | grep -i eth | sed -n -e 's/^.*\(ipaddr=\)//p' | sed -n -e 's/ .*$//p' `

#echo TOPS20_BUILD_HOST=$TOPS20_BUILD_HOST
export TOPS20_BUILD_HOST=$TOPS20_BUILD_HOST

