#!/bin/bash
#######################################################
#######  Environment Variables for the build  #########
#######################################################
#set -x

### ### ### ### ### ### ### ### ### ### ### ### ### ###
### TARGET_ARCHITECTURE - intended target hardware
###  for binaries.
###
###  The only valid targets are Linux or PDP10, where
###  the default build target is PDP10.
### ### ### ### ### ### ### ### ### ### ### ### ### ###
DEFAULT_TARGET_ARCHITECTURE=PDP10  #LINUX
if [ -z $TARGET_ARCHITECTURE ]; then
  TARGET_ARCHITECTURE=$DEFAULT_TARGET_ARCHITECTURE
  echo TARGET_ARCHITECTURE not defined
elif [[ "${TARGET_ARCHITECTURE,,}" = "pdp10" ]] || [[ "${TARGET_ARCHITECTURE,,}" = "linux" ]]; then
  TARGET_ARCHITECTURE=${TARGET_ARCHITECTURE^^}
else
  echo Invalid value for TARGET_ARCHITECTURE, \($TARGET_ARCHITECTURE\)
  TARGET_ARCHITECTURE=$DEFAULT_TARGET_ARCHITECTURE
fi
export TARGET_ARCHITECTURE=${TARGET_ARCHITECTURE^^}
echo Using TARGET_ARCHITECTURE=$TARGET_ARCHITECTURE


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### Use the ENLISTMENT_ROOT to set the PROJECT_ROOT
###  The ENLISTMENT_ROOT should point to the dir
###  where you store all clones. In my case, the
###  "source" directory is where I clone repos.
###
### Under the ENLISTMENT_ROOT, I have a dynamic 
### link "current_dxmos" which points to my working
### directory (current clone).
###
### 
###
### ### ### ### ### ### ### ### ### ### ### ### ### ###=
ENLISTMENT_ROOT=${ENLISTMENT_ROOT:-$HOME/source}
PROJECT_ROOT=${PROJECT_ROOT:-$ENLISTMENT_ROOT/current_dxmos}
export PROJECT_ROOT


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### Define tools in the root of the source tree
### ### ### ### ### ### ### ### ### ### ### ### ### ###
export TOOLS_ROOT=${TOOLS_ROOT:-$ENLISTMENT_ROOT/tools}
export TOOLS_BIN_PATH=$TOOLS_ROOT/bin
export TOOLS_SCRIPT_PATH=$TOOLS_ROOT/scripts

### LOCAL: used to udate PATH, below
TOOLS_EXE_PATH=$TOOLS_BIN_PATH:$TOOLS_SCRIPT_PATH


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### Reset Path to include build TOOLS
### ### ### ### ### ### ### ### ### ### ### ### ### ###
if [ -n "${_PATH+set}" ]; then
    ## We have a saved path (_PATH), restore it
    export PATH=$_PATH
    echo _PATH found
else
    ## We need to saved path as (_PATH)
    export _PATH=$PATH
    echo No _PATH found
fi
export PATH=$TOOLS_EXE_PATH:$PATH


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### Location of the make rules
### ### ### ### ### ### ### ### ### ### ### ### ### ###
export MAKE_RULES_PATH=$TOOLS_ROOT/makeRules


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### points to the root of entire source tree
### ### ### ### ### ### ### ### ### ### ### ### ### ###
export SOURCE_ROOT=$PROJECT_ROOT


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### Location where build places binary targets
### ### ### ### ### ### ### ### ### ### ### ### ### ###
BINARY_ROOT=${BINARY_ROOT:-$ENLISTMENT_ROOT/build}
export BINARY_ROOT


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### The locations for build targets
### ### ### ### ### ### ### ### ### ### ### ### ### ###
export INC_ROOT=$BINARY_ROOT/inc
export OBJ_ROOT=$BINARY_ROOT/obj
export LIB_ROOT=$BINARY_ROOT/lib
export BIN_ROOT=$BINARY_ROOT/exe


### ### ### ### ### ### ### ### ### ### ### ### ### ###
### The locations for exporting items 
### ### ### ### ### ### ### ### ### ### ### ### ### ###
export EXPORT_ROOT=$BINARY_ROOT/export
export EXPORT_INC_ROOT=$EXPORT_ROOT/inc
export EXPORT_OBJ_ROOT=$EXPORT_ROOT/obj
export EXPORT_LIB_ROOT=$EXPORT_ROOT/lib
export EXPORT_BIN_ROOT=$EXPORT_ROOT/exe


#######################################################
#######  Functions and Aliasesm for the build  ########
#######################################################
alias build='make -I $MAKE_RULES_PATH -f $MAKE_RULES_PATH/XKL_MakeCustom'

## Using these functions, you can use a target path in the command;
##   src dxmos/badl
## will move you to sub-directory dxmso/badl within your source tree.
function root()  { cd $ENLISTMENT_ROOT/$1; }
function src()   { cd $SOURCE_ROOT/$1;  }
function bld()   { cd $BUILD_ROOT/$1;   }
function tools() { cd $TOOLS_ROOT/$1;   }

#set -
