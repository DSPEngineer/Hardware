#!/bin/bash

git config --global user.name "Jose Pagan"
git config --global user.email "jpagan@xkl.com"
git config --global push.default matching
#git config --global push.default simple


#user.name=Jose Pagan
#user.email=jpagan@xkl.com
#core.editor=emacs
#core.repositoryformatversion=0
#core.filemode=true
#core.bare=false
#core.logallrefupdates=true
#remote.origin.url=/home/jpagan/source/git.working/../git_repo/
#remote.origin.fetch=+refs/heads/*:refs/remotes/origin/*
#branch.r-dxmos-3.3.remote=origin
#branch.r-dxmos-3.3.merge=refs/heads/r-dxmos-3.3
#branch.r-dxmos-3.5.remote=origin
#branch.r-dxmos-3.5.merge=refs/heads/r-dxmos-3.5
