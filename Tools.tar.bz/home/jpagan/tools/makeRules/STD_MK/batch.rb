#!/opt/xkl/env/1.0/bin/ruby

if ARGV.length != 4
  puts "Usage: #{File.basename($PROGRAM_NAME)} tofetch_file tobuild_file first_file ctl_file"
end

fetchfile, buildfile, firstfile, ctlfile = ARGV
builddir = Dir.pwd

if File.exist?(firstfile)
  first = File.read(firstfile).split
else
  first = []
end
if File.exist?(fetchfile)
  tofetch = File.read(fetchfile).split.uniq
else
  tofetch = []
end
if File.exist?(buildfile)
  tobuild = File.read(buildfile).split.uniq
else
  tobuild = []
end
tostore = tobuild

#
# The intersection of these two lists are intermediate files which must
# be built and not fetched.  
#
intermediate = tofetch & tobuild
tofetch -= intermediate
tobuild -= intermediate

fetch_mfiles = []
fetch_sfiles = []
fetch_asmfiles = []
fetch_cclfiles = []

tofetch.each do |f|
  if    f =~ /.mac$/ then fetch_mfiles += [f]
  elsif f =~ /.s$/   then fetch_sfiles += [f]
  elsif f =~ /.asm$/ then fetch_asmfiles += [f]
  elsif f =~ /.ccl$/ then fetch_cclfiles += [f]
  end
end

#
# Augment the list of files to fetch with the link payload
#
todatfetch = Dir[builddir + "/link_extra/*"]

if fetch_cclfiles.length > 1
  puts "Error: can only use one ccl file, found: #{fetch_cclfiles}"
  exit(1)
end

out = open(ctlfile, "w")

# Turn off history so that buffer doesn't overflow
out.puts("set history 0")

#
# Generate xfetch commands, putting up to 24 files on each command,
# so the command line buffer isn't overrun.
#
count = 0
tofetch.each do |f|
  if count == 0
    out.print("xfetch")
  end
  out.print(" #{File.expand_path(f)}")
  if count == 24
    out.puts(" ./")	# Destination directory
    count = 0
  else
    count += 1
  end
end

if count != 0
  out.puts(" ./")	# Finish final fetch command
end

#
# Generate xfetch commands, putting up to 24 files on each command,
# so the command line buffer isn't overrun.
#
count = 0
todatfetch.each do |f|
  if count == 0
    out.print("xfetch -t")
  end
  out.print(" #{File.expand_path(f)}")
  if count == 24
    out.puts(" ./")	# Destination directory
    count = 0
  else
    count += 1
  end
end

if count != 0
  out.puts(" ./")	# Finish final fetch command
end

sources = fetch_mfiles + fetch_asmfiles + fetch_sfiles

first.each_index do |i|
  first[i] = File.basename(first[i])
end
sources.each_index do |i|
  sources[i] = File.basename(sources[i])
end

# Strip files we don't need to build from the "assemble first" list
first = first & sources

sources -= first

first.each do |f|
  out.puts("compile/macro #{f}")
end
sources.each do |f|
  out.puts("compile/macro #{f}")
end

if fetch_cclfiles.length == 1
  out.puts("link")
  out.puts("*@#{File.basename(fetch_cclfiles[0])}")
end

#
# The XSTORE:: tag is added because there's at least one bug where link
# will save a .exe file even if it has an error.  So if there is an
# error anywhere along the line, all .exe files need to be deleted.
#
# The batch process will drop down to the %err: label at the end of the
# ctl script, then the 'backto xstore' command will bring processing
# back up to here, so it will still store whatever was built so far
# regardless of error(s).
#
# @noerror tells batch to not stop on any xstore failures, keep going to
# try to store everything possible, and delete everything.
#
# The logout is then done per Craig's request that we not print "%err:"
# when there are no errors.
#
out.puts("XSTORE::")
out.puts("@noerror")

# Have to use individual xstore commands so that case sensitivity
# is preserved.
tostore.each do |f|
  out.puts("xstore #{File.basename(f)} #{builddir}/#{f}");
end


# Just delete the whole directory.  It should be empty anyway.
out.puts("delete *.*.*")
out.puts("undelete #{ctlfile}")
out.puts("undelete #{ctlfile.sub(/ctl$/,'log')}")

# # Here's what to do if we want to delete only fetched and built files,
# # though some may get missed if we do this.
# todelete = tofetch + tostore
# todelete.each do |f|
#   out.puts("delete #{File.basename(f)}")
# end

out.puts('expunge')
out.puts('logout')

out.puts("%err:")
out.puts("@delete *.exe")
out.puts("@backto XSTORE")
