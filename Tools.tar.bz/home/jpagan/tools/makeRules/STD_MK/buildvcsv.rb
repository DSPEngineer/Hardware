#!/opt/xkl/env/1.0/bin/ruby

require 'fileutils'
# TODO: Figure out how to use this.  Right now I get a lot of
#   "warning: shadowing outer local variable" complaints
#require 'mercurial-ruby'
#require 'date'

if ARGV.length != 2
  puts "usage: $0 <input file> <output file>"
  exit!
end

infile, outfile = ARGV

unless File.exist?(infile)
  puts "File #{infile} does not exist."
  exit!
end

longname,
shortname,
vername,
majver,
minver,
subver,
apiver,
codename,
gcc,
basedir,
production,
macro,
subrepos = File.read(infile).split(/\n/)

absdir = File.realdirpath(basedir)

gccver = `#{gcc} --version`.lines[0]
gccver = gccver.sub(/.*\(GCC\) (\d+\.\d+\.\d+\.[\da-z-]+).*/, '\1').chomp
now = Time.now.utc.strftime("%Y-%m-%d  %T UTC")
hgid = `hg id -R #{basedir} -ib`.strip
url = "hg://#{ENV['USER']}@#{ENV['HOST']}#{absdir}"

if production == "1"
  if m = absdir.match(/(\d{5}-\d{5}-\d{2})/)
    part = m				# Extract just the part number
  else
    part = "99999-99999-99"		# No part num, default to this.
  end
else
  part = 0
end


out = open(outfile, "w")

if ("0" == macro)
  out.puts "#include \"vcsv.h\""
  out.puts "const char *const VCSV_Date = \"#{now}\";"
  out.puts "const char *const VCSV_LongName = \"#{longname}\";\n"
  out.puts "const char *const VCSV_ShortName = \"#{shortname}\";\n"
  out.puts "const char *const VCSV_VerName = \"#{vername}\";\n"
  out.puts "const char *const VCSV_URL = \"#{url}\";"
  out.puts "const int VCSV_MajorVersion = #{majver};"
  out.puts "const int VCSV_MinorVersion = #{minver};"
  out.puts "const int VCSV_SubVersion   = #{subver};"
  out.puts "const int VCSV_APIVersion   = #{apiver};"
  out.puts "const char *const VCSV_CodeName = \"#{codename}\";"
  out.puts "const char *const VCSV_VCSVVersion = \"#{hgid}\";"
  out.puts "const char *const VCSV_GCCVersion = \"#{gccver}\";"
  out.puts "const char *const VCSV_XKLSoftwarePartNum = \"#{part}\";"
  out.puts "const char *const VCSV_RepoVersions[][2] = {"
  out.puts "     {\"#{absdir}\", \"#{hgid}\"},"
else
  out.puts "	TITLE	vcsv\n	EXTERN ONE"
  out.puts "	.P0807==55B5"
  out.puts "	.PSECT	TEXT"
  out.puts "Radix 10"
  out.puts "%$V$C$S$V.$Date:: ASCIZ8 \"#{now}\""
  out.puts "%$V$C$S$V.$Long$Name:: ASCIZ8 \"#{longname}\""
  out.puts "%$V$C$S$V.$Short$Name:: ASCIZ8 \"#{shortname}\""
  out.puts "%$V$C$S$V.$Ver$Name:: ASCIZ8 \"#{vername}\""
  out.puts "%$V$C$S$V.$U$R$L:: ASCIZ8 \"#{url}\""
  out.puts "%$V$C$S$V.$Major$Version==: #{majver}"
  out.puts "%$V$C$S$V.$Minor$Version==: #{minver}"
  out.puts "%$V$C$S$V.$Sub$Version==: #{subver}"
  out.puts "%$V$C$S$V.$A$P$I$Version==: #{apiver}"
  out.puts "%$V$C$S$V.$Code$Name:: ASCIZ8 \"#{codename}\";"
  out.puts "%$V$C$S$V.$V$C$S$V$Version:: ASCIZ8 \"#{hgid}\""
  out.puts "%$V$C$S$V.$G$C$C$Version:: ASCIZ8 \"#{gccver}\""
  if (0 == part)
    out.puts "%$V$C$S$V.$X$K$L$Software$Part$Num:: 0"
  else
    out.puts "%$V$C$S$V.$X$K$L$Software$Part$Num:: ASCIZ8 \"#{part}\""
  end
  out.puts "%$V$C$S$V.$Repo$Versions::"
  out.puts "	.P0807!<ONE*[ASCIZ8 \"#{absdir}\"]>"
  out.puts "	.P0807!<ONE*[ASCIZ8 \"#{hgid}\"]>"
end

subrepos.split(' ').each do |repo|
  absrepo = File.realdirpath(repo)
  hgid = `hg id -R #{repo} -ib`.strip
  if ("0" == macro)
    out.puts "     {\"#{absrepo}\", \"#{hgid}\"},"
  else
    out.puts "	.P0807!<ONE*[ASCIZ8 \"#{absrepo}\"]>"
    out.puts "	.P0807!<ONE*[ASCIZ8 \"#{hgid}\"]>"
  end
end

if ("0" == macro)
  out.puts "     {0,0}};";
else
  out.puts "	0"
  out.puts "	0";
  out.puts "	.ENDPS";
  out.puts "	END";
end
