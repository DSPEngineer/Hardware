#!/usr/bin/python3
import sys
import re

gettype = re.compile(r"^[^:]*((Error|Warning|Info) [0-9]+):")

errcount = 0
warncount = 0
infocount = 0
interrcount = 0

for line in sys.stdin:
	result = gettype.match(line)
	if result is not None:
		msgtype = result.groups()[0]
		if msgtype[0:5] == 'Error':
			try:
				n = int(msgtype[6:9])
				if n >= 200 and n < 300:
					interrcount += 1
				else:
					errcount += 1
			except ValueError:
				errcount += 1
		elif msgtype[0:7] == 'Warning':
			warncount += 1
		elif msgtype[0:4] == 'Info' and msgtype != 'Info 830' and msgtype != 'Info 831':
			infocount += 1
print('Errors:   %d\nWarnings: %d\nInfo:     %d\n(2xx):    %d\n' %
      (errcount, warncount, infocount, interrcount))

if errcount != 0:
	sys.exit(3)
elif warncount != 0:
	sys.exit(2)
elif infocount != 0:
	sys.exit(1)
else:
	sys.exit(0)

# Copyright (c) 2011-2012 Pikopiko Network / Noukon Dokyou Kai Software
# Assembly

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to
# deal in the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
# sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

